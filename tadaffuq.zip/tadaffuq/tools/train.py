#!/usr/bin/env python3
"""تدريب نموذج الكشف (انحدار لوجستي) ثم تصدير model.json للتطبيق.

الاستخدام:
    python3 tools/train.py tools/sample_data.csv --out model.json

الملف: عمودان text,label  (label=1 مزوّر/احتيالي، 0 سليم).
يعتمد على numpy فقط. منطق الخصائص هنا يطابق Signals في FraudRules.kt —
عند تعديل أحدهما عدّل الآخر.
"""
import argparse
import csv
import json
import math
import re
import sys
from datetime import date, timedelta
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
KEYWORDS = ROOT / "app/src/main/assets/keywords.json"

FEATURES = ["has_link", "short_link", "untrusted_link", "urgency_count", "sensitive_ask", "action_verb",
            "has_ref", "has_amount", "has_phone", "exclam", "mixed_script", "future_date",
            "upper_ratio", "digit_ratio", "length_norm"]

ARABIC_INDIC = "٠١٢٣٤٥٦٧٨٩"
EASTERN_INDIC = "۰۱۲۳۴۵۶۷۸۹"


def normalize(raw: str) -> str:
    out = []
    for c in raw:
        if c in ARABIC_INDIC:
            out.append(str(ARABIC_INDIC.index(c)))
        elif c in EASTERN_INDIC:
            out.append(str(EASTERN_INDIC.index(c)))
        elif c == "٫":
            out.append(".")
        elif c in "٬،":
            out.append(",")
        else:
            out.append(c)
    s = "".join(out)
    s = re.sub(r"[ً-ْـ]", "", s)
    s = s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ة", "ه").replace("ى", "ي")
    return re.sub(r"\s+", " ", s).strip()


CUR = r"(?:SDG|SAR|USD|EGP|AED|QAR|KWD|جنيه|ج\.س|ريال|دولار|درهم|دينار|\$)"
NUM = r"(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)"
AMOUNT = [re.compile(NUM + r"\s*(" + CUR + ")", re.I), re.compile("(" + CUR + r")\s*" + NUM, re.I),
          re.compile(r"(?:مبلغ|amount)\s*:?\s*" + NUM, re.I)]
REF = re.compile(r"(?:ref(?:erence)?(?: no)?\.?|رقم العمليه|رقم المرجع|رقم المعامله|المرجع|مرجع|transaction id|txn)"
                 r"\s*[:#\-]?\s*([A-Za-z0-9]{6,})", re.I)
DATE_YMD = re.compile(r"(?<!\d)(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?!\d)")
DATE_DMY = re.compile(r"(?<!\d)(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})(?!\d)")
LINK = re.compile(r"\b(?:https?://|www\.)\S+|\b[a-z0-9-]+\.(?:com|net|org|info|xyz|top|online|site|link|cc|tk|ml|ly|gl)/\S*", re.I)
PHONE = re.compile(r"(?<!\d)\+?\d{9,14}(?!\d)")


def load_keywords():
    k = json.loads(KEYWORDS.read_text(encoding="utf-8"))
    return {key: [normalize(w).lower() for w in vals] for key, vals in k.items()}


def hit(text, kw):
    if all(ord(ch) < 128 for ch in kw):
        return re.search(r"\b" + re.escape(kw) + r"\b", text) is not None
    return kw in text


def domain_of(link):
    d = link.lower()
    for p in ("https://", "http://", "www."):
        if d.startswith(p):
            d = d[len(p):]
    return re.split(r"[/?]", d)[0]


def features(raw, kw, today=None):
    today = today or date.today()
    t = normalize(raw)
    low = t.lower()
    has_amount = any(r.search(t) for r in AMOUNT)
    m = REF.search(t)
    ref = m.group(1) if m else None
    links = [l.rstrip(".,)") for l in LINK.findall(t)]
    phones = [p for p in PHONE.findall(t) if p != ref]
    domains = [domain_of(l) for l in links]
    short = any(d == s or d.endswith("." + s) for d in domains for s in kw["shorteners"])
    untrusted = any(all(not (d == td or d.endswith("." + td)) for td in kw["trusted_domains"]) for d in domains)
    urgency = sum(1 for w in kw["urgency"] if hit(low, w))
    action = any(hit(low, w) for w in kw["actions"])
    sensitive = any(hit(low, w) for w in kw["sensitive"]) and (action or bool(links))

    future = False
    mm = DATE_YMD.search(t)
    try:
        if mm:
            d = date(int(mm.group(1)), int(mm.group(2)), int(mm.group(3)))
        else:
            mm = DATE_DMY.search(t)
            d = date(int(mm.group(3)), int(mm.group(2)), int(mm.group(1))) if mm else None
        future = d is not None and d > today + timedelta(days=1)
    except ValueError:
        future = False

    mixed = any(any("؀" <= c <= "ۿ" for c in w) and any("a" <= c <= "z" for c in w) for w in low.split(" "))
    latin = [c for c in t if "a" <= c.lower() <= "z" and c.isascii()]
    upper = sum(c.isupper() for c in latin) / len(latin) if latin else 0.0
    n = max(len(t), 1)
    digits = sum(c.isdigit() for c in t) / n
    b = float
    return [b(bool(links)), b(short), b(untrusted), min(urgency, 3) / 3.0, b(sensitive), b(action),
            b(ref is not None), b(has_amount), b(bool(phones)), min(t.count("!"), 3) / 3.0, b(mixed), b(future),
            upper, digits, min(n / 300.0, 1.0)]


def train(X, y, epochs=3000, lr=0.5, l2=0.01):
    w = np.zeros(X.shape[1])
    bias = 0.0
    for _ in range(epochs):
        p = 1 / (1 + np.exp(-(X @ w + bias)))
        g = p - y
        w -= lr * (X.T @ g / len(y) + l2 * w)
        bias -= lr * g.mean()
    return w, bias


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--out", default="model.json")
    a = ap.parse_args()

    kw = load_keywords()
    rows = list(csv.DictReader(open(a.csv, encoding="utf-8")))
    X = np.array([features(r["text"], kw) for r in rows])
    y = np.array([float(r["label"]) for r in rows])
    if len(set(y)) < 2:
        sys.exit("البيانات يجب أن تحتوي فئتين (0 و 1)")

    w, b = train(X, y)
    pred = 1 / (1 + np.exp(-(X @ w + b)))
    acc = ((pred >= 0.5) == (y == 1)).mean()
    print(f"عدد العينات: {len(y)} — دقة التدريب: {acc:.2%}")
    print("تنبيه: الدقة على بيانات التدريب فقط؛ قيّم على عينات لم يرها النموذج قبل الاعتماد عليه.")

    Path(a.out).write_text(json.dumps(
        {"features": FEATURES, "weights": [round(float(v), 4) for v in w], "bias": round(float(b), 4)},
        ensure_ascii=False, indent=2), encoding="utf-8")
    print("تم الحفظ:", a.out)


if __name__ == "__main__":
    main()
