package com.tadaffuq.app

import android.content.Context
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

enum class Level(val label: String) {
    SAFE("إشعار سليم — لا خلل"),
    SUSPICIOUS("مشبوه / فيه خلل"),
    FORGED("مزوّر على الأرجح"),
    DUPLICATE("احتيال: رقم العملية مكرر"),
    ACCOUNT_MISMATCH("تنبيه: خلل في رقم الحساب"),
}

data class Analysis(
    val parsed: ParsedNotice,
    val rawText: String,
    val level: Level,
    val score: Double,
    val mlScore: Double,
    val ruleScore: Double,
    val reasons: List<String>,
    val duplicate: DupResult,
    val accountStatus: AccountStatus,
    val official: OfficialFields?,
) {
    /** يُدخل في الإكسل فقط إذا كان الإشعار بالصيغة الرسمية الكاملة وبلا أي خلل. */
    val canRecord: Boolean
        get() = level == Level.SAFE && official?.isComplete == true
}

data class Recorded(val file: File?)

class Analyzer(ctx: Context) {
    private val app = ctx.applicationContext
    private val db = HistoryDb(app)
    private val keywords = Keywords.load(app)
    private val model = MlModel.load(app)
    private val dup = DuplicateDetector(db)
    val accountStore = AccountStore(app)

    private val dtFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

    val exportDir: File
        get() = (app.getExternalFilesDir("exports") ?: File(app.filesDir, "exports")).apply { mkdirs() }

    /** manualRef: رقم عملية أدخله العميل يدوياً ليحل محل ما قرأه OCR. */
    fun analyze(raw: String, manualRef: String? = null): Analysis {
        val official = OfficialParser.parse(raw)
        var parsed = NotificationParser.parse(raw)
        if (official != null) {
            parsed = parsed.copy(
                reference = official.operationNumber ?: parsed.reference,
                amount = official.amount ?: parsed.amount,
                currency = parsed.currency ?: "SDG",
                dateTime = official.dateTime?.format(dtFmt) ?: parsed.dateTime,
                accounts = listOfNotNull(official.toAccount),
            )
        }
        val ref = manualRef?.trim()?.takeIf { it.isNotEmpty() }
        if (ref != null) parsed = parsed.copy(reference = ref)

        val signals = Signals.from(parsed, keywords)
        val hits = FraudRules.evaluate(parsed, signals)
        val ruleScore = FraudRules.score(hits)
        val mlScore = model.predict(signals)
        val score = 0.6 * mlScore + 0.4 * ruleScore
        val d = dup.check(parsed)

        val mine = accountStore.account
        val acct = if (official != null) {
            when {
                mine.isBlank() -> AccountStatus.NOT_SET
                official.toAccount == null -> AccountStatus.NOT_FOUND
                official.toAccount == mine -> AccountStatus.MATCH
                else -> AccountStatus.MISMATCH
            }
        } else AccountStore.check(mine, parsed.accounts)

        val reasons = hits.map { it.reason }.toMutableList()
        if (official == null) {
            reasons.add(0, "الإشعار لا يطابق صيغة إشعار بنك الخرطوم الرسمية (لم تُقرأ عناوين الحقول)")
        } else {
            reasons.addAll(0, official.problems)
        }
        when (acct) {
            AccountStatus.MISMATCH -> reasons.add(
                0, "«الى حساب» في الإشعار (${official?.toAccount ?: parsed.accounts.joinToString()}) لا يطابق حسابك المسجّل ($mine)"
            )
            AccountStatus.NOT_FOUND -> reasons.add("لم يُعثر على رقم الحساب المستلم في الإشعار")
            else -> {}
        }
        if (d.isDuplicate && d.reason != null) reasons.add(0, d.reason)

        val flawed = official == null || official.problems.isNotEmpty() || parsed.reference == null
        val level = when {
            d.isDuplicate && d.byReference -> Level.DUPLICATE
            acct == AccountStatus.MISMATCH -> Level.ACCOUNT_MISMATCH
            score >= 0.70 -> Level.FORGED
            d.isDuplicate -> Level.DUPLICATE
            score >= 0.40 || flawed || acct != AccountStatus.MATCH -> Level.SUSPICIOUS
            else -> Level.SAFE
        }
        return Analysis(parsed, raw, level, score, mlScore, ruleScore, reasons, d, acct, official)
    }

    /** إن كان الإشعار سليماً تماماً: يسجّل رقم العملية ويحدّث ملف إكسل ذلك اليوم. */
    fun recordIfValid(a: Analysis): Recorded? {
        if (!a.canRecord) return null
        val dt = a.official?.dateTime ?: return null
        val op = a.parsed.reference ?: return null
        val amount = a.parsed.amount ?: return null
        val day = dt.toLocalDate().toString()

        if (db.insertTransfer(day, dt.format(dtFmt), op, amount) < 0) return null
        db.insert(a.parsed, a.level.name)
        return Recorded(exportDay(day))
    }

    /** يسجّل نتيجة الفحص في السجل ويُدخل الإشعار السليم في الإكسل. هذه هي نقطة الدخول من الواجهة. */
    fun process(a: Analysis): Recorded? {
        val rec = recordIfValid(a)
        db.logScan(
            LocalDate.now().toString(), a.parsed.dateTime, a.parsed.reference, a.parsed.amount,
            a.level.name, rec != null, a.reasons.firstOrNull(),
        )
        return rec
    }

    /** يعيد بناء ملف إكسل ذلك اليوم من القاعدة ويرجعه (null عند الفشل). */
    fun exportDay(day: String): File? = try {
        File(exportDir, "tadaffuq_$day.xlsx").also { XlsxWriter.writeDaily(it, db.transfersForDay(day)) }
    } catch (e: Exception) {
        null
    }

    fun stats(day: String): DayStats = db.statsFor(day)
    fun recentScans(limit: Int): List<ScanEntry> = db.recentScans(limit)
    fun daySummaries(): List<DaySummary> = db.daySummaries()
    fun clearHistory() = db.clear()
}
