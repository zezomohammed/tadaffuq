package com.tadaffuq.app

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class OcrEngine(private val ctx: Context) {

    /** ينسخ ara/eng.traineddata من assets/tessdata إلى مجلد التطبيق عند أول تشغيل. */
    private fun ensureData(): String {
        val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
        for (lang in listOf("ara", "eng")) {
            val f = File(dir, "$lang.traineddata")
            if (!f.exists()) {
                try {
                    ctx.assets.open("tessdata/$lang.traineddata").use { i ->
                        f.outputStream().use { o -> i.copyTo(o) }
                    }
                } catch (e: java.io.FileNotFoundException) {
                    throw IllegalStateException(
                        "ملف $lang.traineddata غير موجود في app/src/main/assets/tessdata — راجع README."
                    )
                }
            }
        }
        return ctx.filesDir.absolutePath
    }

    private fun prepare(b: Bitmap): Bitmap =
        if (b.width < 800) Bitmap.createScaledBitmap(b, b.width * 2, b.height * 2, true) else b

    fun read(bitmap: Bitmap): String {
        val api = TessBaseAPI()
        try {
            check(api.init(ensureData(), "ara+eng")) { "تعذّر تشغيل محرك OCR" }
            api.setImage(prepare(bitmap))
            return api.utF8Text ?: ""
        } finally {
            api.recycle()
        }
    }
}
