package com.tadaffuq.app

import android.content.Context

enum class AccountStatus { NOT_SET, MATCH, MISMATCH, NOT_FOUND }

/** حساب العميل المستلم، يُدخله العميل قبل بدء التصوير. */
class AccountStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("tadaffuq", Context.MODE_PRIVATE)

    var account: String
        get() = prefs.getString("account", "") ?: ""
        set(v) { prefs.edit().putString("account", v.trim()).apply() }

    companion object {
        private fun digits(s: String) = NotificationParser.normalize(s).filter { it.isDigit() }
        private fun masked(s: String) = s.any { it == '*' || it == '•' || it == 'x' || it == 'X' }

        /** يقارن الحسابات الواردة في الإشعار مع حساب العميل (يدعم الأرقام المقنّعة بمطابقة آخر الخانات). */
        fun check(mine: String, found: List<String>): AccountStatus {
            val m = digits(mine)
            if (m.isEmpty()) return AccountStatus.NOT_SET
            if (found.isEmpty()) return AccountStatus.NOT_FOUND
            val ok = found.any { f ->
                val d = digits(f)
                d.isNotEmpty() && (d == m || (masked(f) && d.length >= 3 && m.endsWith(d)))
            }
            return if (ok) AccountStatus.MATCH else AccountStatus.MISMATCH
        }
    }
}
