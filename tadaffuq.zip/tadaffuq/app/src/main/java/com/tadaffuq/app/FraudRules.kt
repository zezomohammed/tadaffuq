package com.tadaffuq.app

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.min

class Keywords(
    val shorteners: List<String>,
    val urgency: List<String>,
    val sensitive: List<String>,
    val actions: List<String>,
    val trustedDomains: List<String>,
) {
    companion object {
        private fun list(o: JSONObject, key: String): List<String> {
            val a = o.getJSONArray(key)
            return (0 until a.length()).map { NotificationParser.normalize(a.getString(it)).lowercase() }
        }

        fun load(ctx: Context): Keywords {
            val o = JSONObject(ctx.assets.open("keywords.json").bufferedReader().use { it.readText() })
            return Keywords(
                list(o, "shorteners"), list(o, "urgency"), list(o, "sensitive"),
                list(o, "actions"), list(o, "trusted_domains"),
            )
        }
    }
}

data class RuleHit(val reason: String, val weight: Int)

/** إشارات مشتركة بين القواعد والنموذج (يجب أن تطابق tools/train.py). */
data class Signals(
    val hasLink: Boolean,
    val shortLink: Boolean,
    val untrustedLink: Boolean,
    val urgencyCount: Int,
    val sensitiveAsk: Boolean,
    val actionVerb: Boolean,
    val hasRef: Boolean,
    val hasAmount: Boolean,
    val hasPhone: Boolean,
    val exclam: Int,
    val mixedScript: Boolean,
    val futureDate: Boolean,
    val upperRatio: Double,
    val digitRatio: Double,
    val lengthNorm: Double,
) {
    fun toVector(): DoubleArray = doubleArrayOf(
        b(hasLink), b(shortLink), b(untrustedLink), min(urgencyCount, 3) / 3.0, b(sensitiveAsk),
        b(actionVerb), b(hasRef), b(hasAmount), b(hasPhone), min(exclam, 3) / 3.0, b(mixedScript),
        b(futureDate), upperRatio, digitRatio, lengthNorm,
    )

    private fun b(x: Boolean) = if (x) 1.0 else 0.0

    companion object {
        val FEATURE_NAMES = listOf(
            "has_link", "short_link", "untrusted_link", "urgency_count", "sensitive_ask", "action_verb",
            "has_ref", "has_amount", "has_phone", "exclam", "mixed_script", "future_date",
            "upper_ratio", "digit_ratio", "length_norm",
        )

        private fun hit(text: String, kw: String): Boolean =
            if (kw.all { it.code < 128 }) Regex("\\b" + Regex.escape(kw) + "\\b").containsMatchIn(text)
            else text.contains(kw)

        private fun domainOf(link: String): String =
            link.lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.")
                .substringBefore('/').substringBefore('?')

        fun from(p: ParsedNotice, kw: Keywords, today: LocalDate = LocalDate.now()): Signals {
            val text = p.normalized.lowercase()
            val domains = p.links.map { domainOf(it) }
            val shortLink = domains.any { d -> kw.shorteners.any { d == it || d.endsWith(".$it") } }
            val untrusted = domains.any { d -> kw.trustedDomains.none { d == it || d.endsWith(".$it") } }
            val urgency = kw.urgency.count { hit(text, it) }
            val action = kw.actions.any { hit(text, it) }
            val sensitive = kw.sensitive.any { hit(text, it) } && (action || p.links.isNotEmpty())

            val future = p.dateTime?.take(10)?.let {
                try { LocalDate.parse(it).isAfter(today.plusDays(1)) } catch (e: Exception) { false }
            } ?: false

            val mixed = text.split(" ").any { w ->
                w.any { it in '؀'..'ۿ' } && w.any { it in 'a'..'z' }
            }
            val latin = p.normalized.filter { it in 'A'..'Z' || it in 'a'..'z' }
            val upper = if (latin.isEmpty()) 0.0 else latin.count { it in 'A'..'Z' }.toDouble() / latin.length
            val len = p.normalized.length.coerceAtLeast(1)
            val digits = p.normalized.count { it.isDigit() }.toDouble() / len

            return Signals(
                hasLink = p.links.isNotEmpty(), shortLink = shortLink, untrustedLink = untrusted,
                urgencyCount = urgency, sensitiveAsk = sensitive, actionVerb = action,
                hasRef = p.reference != null, hasAmount = p.amount != null,
                hasPhone = p.phones.isNotEmpty(), exclam = p.normalized.count { it == '!' },
                mixedScript = mixed, futureDate = future, upperRatio = upper, digitRatio = digits,
                lengthNorm = min(len / 300.0, 1.0),
            )
        }
    }
}

object FraudRules {
    private val transactionWords = listOf("خصم", "ايداع", "تحويل", "سحب", "debit", "credit", "transfer", "withdraw", "purchase", "شراء")

    /** يرجع الأسباب مع الأوزان؛ المجموع يُحوَّل إلى 0..1. */
    fun evaluate(p: ParsedNotice, s: Signals): List<RuleHit> {
        val hits = mutableListOf<RuleHit>()
        if (s.shortLink) hits += RuleHit("يحتوي رابطاً مختصراً (يخفي الوجهة الحقيقية)", 3)
        else if (s.hasLink && s.untrustedLink) hits += RuleHit("يحتوي رابطاً غير معتمد — البنوك نادراً ما ترسل روابط في إشعارات العمليات", 2)
        if (s.urgencyCount >= 2) hits += RuleHit("لغة استعجال وتهديد (إيقاف/تجميد الحساب...)", 3)
        else if (s.urgencyCount == 1) hits += RuleHit("لغة استعجال أو تهديد", 2)
        if (s.sensitiveAsk) hits += RuleHit("يطلب بيانات حساسة (رقم سري/OTP/بطاقة) أو يوجّه لإدخالها", 4)
        if (s.hasLink && s.actionVerb) hits += RuleHit("يطلب منك الضغط/الدخول عبر رابط", 1)
        if (s.hasPhone && s.actionVerb) hits += RuleHit("يطلب الاتصال برقم وارد في الرسالة", 2)
        val txt = p.normalized.lowercase()
        val isTransaction = s.hasAmount || transactionWords.any { txt.contains(it) }
        if (isTransaction && !s.hasRef) hits += RuleHit("إشعار عملية بدون رقم مرجع", 1)
        if (s.futureDate) hits += RuleHit("تاريخ العملية في المستقبل", 2)
        if (s.mixedScript) hits += RuleHit("كلمات تخلط حروفاً عربية ولاتينية (علامة تزوير أو خطأ قراءة)", 1)
        if (s.exclam >= 2) hits += RuleHit("علامات تعجب كثيرة", 1)
        return hits
    }

    fun score(hits: List<RuleHit>): Double = min(hits.sumOf { it.weight } / 10.0, 1.0)
}
