package com.tadaffuq.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tadaffuq.app.AppState
import com.tadaffuq.app.DayStats
import com.tadaffuq.app.Level
import com.tadaffuq.app.ScanEntry
import com.tadaffuq.app.money

class ScanActions(val onPick: () -> Unit, val onCamera: () -> Unit)

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun EmptyState(emoji: String, title: String, hint: String) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(emoji, fontSize = 40.sp)
        Text(title, fontWeight = FontWeight.Bold)
        Text(hint, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun HomeScreen(state: AppState, actions: ScanActions) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Column {
            Text("تدفق", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = cs.primary)
            Text("تحقّق من إشعارات التحويل قبل أن تصدّقها", fontSize = 14.sp, color = cs.onSurfaceVariant)
        }

        if (state.account.isBlank()) {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ابدأ بإضافة حسابك", fontWeight = FontWeight.Bold)
                    Text(
                        "أدخل رقم حسابك المستلِم أولاً ليتحقق تدفق من أن كل إشعار موجّه إلى حسابك فعلاً.",
                        fontSize = 13.sp,
                    )
                    Button(onClick = { state.tab = 3 }, shape = RoundedCornerShape(14.dp)) { Text("إضافة الحساب") }
                }
            }
        }

        HeroCard(state.stats)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("📷", "تصوير", actions.onCamera)
            ActionTile("🖼️", "من المعرض", actions.onPick)
            ActionTile("📊", "تصدير اليوم") { state.exportAndShare(ctx, state.today()) }
        }

        SectionTitle("آخر الإشعارات")
        if (state.recent.isEmpty()) {
            EmptyState("🧾", "لا توجد إشعارات بعد", "صوّر أول إشعار تحويل وسيظهر هنا مع حالته.")
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                state.recent.forEach { NoticeRow(it) }
            }
        }
    }
}

@Composable
private fun HeroCard(s: DayStats) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(HeroBrush).padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("تدفق اليوم", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(money(s.total), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Spacer(Modifier.width(6.dp))
                Text("ج.س", color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat("مؤكدة", s.confirmed)
                Stat("تنبيهات", s.flagged)
                Stat("المفحوصة", s.confirmed + s.flagged)
            }
        }
    }
}

@Composable
private fun RowScope.Stat(label: String, value: Int) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.16f)).padding(12.dp)
    ) {
        Text(value.toString(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
    }
}

@Composable
private fun RowScope.ActionTile(emoji: String, label: String, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(emoji, fontSize = 26.sp)
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun NoticeRow(e: ScanEntry) {
    val cs = MaterialTheme.colorScheme
    val level = runCatching { Level.valueOf(e.level) }.getOrDefault(Level.SUSPICIOUS)
    val c = levelColor(level)
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(c.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(if (level == Level.SAFE) "✓" else "!", color = c, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
            Column(Modifier.weight(1f)) {
                Text(e.op ?: "رقم عملية غير مقروء", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(e.dt ?: "—", fontSize = 12.sp, color = cs.onSurfaceVariant)
                if (!e.recorded && e.reason != null) {
                    Text(e.reason, fontSize = 12.sp, color = c, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(e.amount?.let { money(it) } ?: "—", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                StatusChip(levelShort(level), c)
            }
        }
    }
}
