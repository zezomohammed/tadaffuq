package com.tadaffuq.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Record(
    val id: Long,
    val ts: Long,
    val text: String,
    val reference: String?,
    val amount: Double?,
    val dateTime: String?,
    val level: String,
)

/** سطر في سجل الفحوص (يظهر في الرئيسية). */
data class ScanEntry(
    val id: Long,
    val ts: Long,
    val dt: String?,
    val op: String?,
    val amount: Double?,
    val level: String,
    val recorded: Boolean,
    val reason: String?,
)

data class DayStats(val total: Double = 0.0, val confirmed: Int = 0, val flagged: Int = 0)

data class DaySummary(val day: String, val count: Int, val total: Double)

class HistoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "history.db", null, 3) {

    private fun createTransfers(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS transfers(id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT, " +
                "dt TEXT, op TEXT UNIQUE, amount REAL)"
        )
    }

    private fun createScanLog(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS scan_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, day TEXT, " +
                "dt TEXT, op TEXT, amount REAL, level TEXT, recorded INTEGER, reason TEXT)"
        )
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE records(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, text TEXT, " +
                "ref TEXT, amount REAL, dt TEXT, level TEXT)"
        )
        createTransfers(db)
        createScanLog(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createTransfers(db)
        if (oldVersion < 3) createScanLog(db)
    }

    fun insert(p: ParsedNotice, level: String): Long {
        val v = ContentValues().apply {
            put("ts", System.currentTimeMillis())
            put("text", p.normalized)
            put("ref", p.reference)
            put("amount", p.amount)
            put("dt", p.dateTime)
            put("level", level)
        }
        return writableDatabase.insert("records", null, v)
    }

    /** يرجع -1 إذا كان رقم العملية موجوداً (قيد UNIQUE على مستوى القاعدة). */
    fun insertTransfer(day: String, dt: String, op: String, amount: Double): Long {
        val v = ContentValues().apply {
            put("day", day); put("dt", dt); put("op", op); put("amount", amount)
        }
        return writableDatabase.insertWithOnConflict("transfers", null, v, SQLiteDatabase.CONFLICT_IGNORE)
    }

    /** صفوف اليوم مرتبة بالزمن: {التاريخ والزمن, رقم العملية, المبلغ}. */
    fun transfersForDay(day: String): List<Array<Any>> {
        val out = mutableListOf<Array<Any>>()
        readableDatabase.rawQuery(
            "SELECT dt, op, amount FROM transfers WHERE day = ? ORDER BY dt ASC", arrayOf(day)
        ).use { c ->
            while (c.moveToNext()) out += arrayOf<Any>(c.getString(0), c.getString(1), c.getDouble(2))
        }
        return out
    }

    fun recent(days: Int): List<Record> {
        val since = System.currentTimeMillis() - days * 86_400_000L
        val out = mutableListOf<Record>()
        readableDatabase.rawQuery(
            "SELECT id, ts, text, ref, amount, dt, level FROM records WHERE ts >= ? ORDER BY ts DESC",
            arrayOf(since.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += Record(
                    c.getLong(0), c.getLong(1), c.getString(2),
                    if (c.isNull(3)) null else c.getString(3),
                    if (c.isNull(4)) null else c.getDouble(4),
                    if (c.isNull(5)) null else c.getString(5),
                    c.getString(6),
                )
            }
        }
        return out
    }

    fun logScan(day: String, dt: String?, op: String?, amount: Double?, level: String, recorded: Boolean, reason: String?) {
        val v = ContentValues().apply {
            put("ts", System.currentTimeMillis())
            put("day", day)
            put("dt", dt)
            put("op", op)
            put("amount", amount)
            put("level", level)
            put("recorded", if (recorded) 1 else 0)
            put("reason", reason)
        }
        writableDatabase.insert("scan_log", null, v)
    }

    fun recentScans(limit: Int): List<ScanEntry> {
        val out = mutableListOf<ScanEntry>()
        readableDatabase.rawQuery(
            "SELECT id, ts, dt, op, amount, level, recorded, reason FROM scan_log ORDER BY ts DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += ScanEntry(
                    c.getLong(0), c.getLong(1),
                    if (c.isNull(2)) null else c.getString(2),
                    if (c.isNull(3)) null else c.getString(3),
                    if (c.isNull(4)) null else c.getDouble(4),
                    c.getString(5), c.getInt(6) == 1,
                    if (c.isNull(7)) null else c.getString(7),
                )
            }
        }
        return out
    }

    /** إحصاءات اليوم: المؤكد (حسب تاريخ العملية) والتنبيهات (حسب يوم الفحص). */
    fun statsFor(day: String): DayStats {
        var total = 0.0
        var confirmed = 0
        readableDatabase.rawQuery(
            "SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM transfers WHERE day = ?", arrayOf(day)
        ).use { if (it.moveToFirst()) { confirmed = it.getInt(0); total = it.getDouble(1) } }
        val flagged = readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM scan_log WHERE day = ? AND recorded = 0", arrayOf(day)
        ).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        return DayStats(total, confirmed, flagged)
    }

    fun daySummaries(): List<DaySummary> {
        val out = mutableListOf<DaySummary>()
        readableDatabase.rawQuery(
            "SELECT day, COUNT(*), COALESCE(SUM(amount), 0) FROM transfers GROUP BY day ORDER BY day DESC", null
        ).use { c ->
            while (c.moveToNext()) out += DaySummary(c.getString(0), c.getInt(1), c.getDouble(2))
        }
        return out
    }

    /** يمسح كل السجلات (ملفات الإكسل المصدّرة تبقى كما هي). */
    fun clear() {
        writableDatabase.delete("records", null, null)
        writableDatabase.delete("transfers", null, null)
        writableDatabase.delete("scan_log", null, null)
    }
}
