package com.tadaffuq.app;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** كاتب xlsx بسيط بلا مكتبات خارجية: ورقة واحدة، من اليمين لليسار. */
public final class XlsxWriter {
    private XlsxWriter() {}

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static String strCell(String ref, String v) {
        return "<c r=\"" + ref + "\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" + esc(v) + "</t></is></c>";
    }

    private static void put(ZipOutputStream z, String name, String content) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    /** rows: كل عنصر {String dateTime, String operationNumber, Number amount}. */
    public static void writeDaily(File out, List<Object[]> rows) throws IOException {
        StringBuilder sd = new StringBuilder();
        sd.append("<row r=\"1\">")
          .append(strCell("A1", "التاريخ والزمن"))
          .append(strCell("B1", "رقم العملية"))
          .append(strCell("C1", "المبلغ"))
          .append("</row>");

        BigDecimal total = BigDecimal.ZERO;
        int r = 2;
        for (Object[] row : rows) {
            BigDecimal amt = BigDecimal.valueOf(((Number) row[2]).doubleValue());
            total = total.add(amt);
            sd.append("<row r=\"").append(r).append("\">")
              .append(strCell("A" + r, (String) row[0]))
              .append(strCell("B" + r, (String) row[1]))
              .append("<c r=\"C").append(r).append("\"><v>").append(amt.toPlainString()).append("</v></c>")
              .append("</row>");
            r++;
        }
        if (!rows.isEmpty()) {
            sd.append("<row r=\"").append(r).append("\">")
              .append(strCell("A" + r, "الإجمالي"))
              .append("<c r=\"C").append(r).append("\"><f>SUM(C2:C").append(r - 1).append(")</f><v>")
              .append(total.toPlainString()).append("</v></c></row>");
        }

        String sheet = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
            + "<sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"/></sheetViews>"
            + "<cols><col min=\"1\" max=\"1\" width=\"24\" customWidth=\"1\"/>"
            + "<col min=\"2\" max=\"2\" width=\"18\" customWidth=\"1\"/>"
            + "<col min=\"3\" max=\"3\" width=\"16\" customWidth=\"1\"/></cols>"
            + "<sheetData>" + sd + "</sheetData></worksheet>";

        String contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
            + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
            + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
            + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
            + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
            + "</Types>";

        String rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
            + "</Relationships>";

        String workbook = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
            + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
            + "<sheets><sheet name=\"التحويلات\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";

        String wbRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
            + "</Relationships>";

        File tmp = new File(out.getParentFile(), out.getName() + ".tmp");
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(tmp))) {
            put(z, "[Content_Types].xml", contentTypes);
            put(z, "_rels/.rels", rootRels);
            put(z, "xl/workbook.xml", workbook);
            put(z, "xl/_rels/workbook.xml.rels", wbRels);
            put(z, "xl/worksheets/sheet1.xml", sheet);
        }
        if (out.exists() && !out.delete()) throw new IOException("تعذّر استبدال الملف القديم");
        if (!tmp.renameTo(out)) throw new IOException("تعذّر حفظ الملف");
    }
}
