package com.tadaffuq.app

data class DupResult(
    val isDuplicate: Boolean,
    val matchId: Long? = null,
    val reason: String? = null,
    val similarity: Double = 0.0,
    val byReference: Boolean = false, // true = نفس رقم العملية تماماً (يُعدّ احتيالاً)
)

class DuplicateDetector(private val db: HistoryDb) {

    private fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return a.intersect(b).size.toDouble() / a.union(b).size
    }

    fun check(p: ParsedNotice): DupResult {
        val mine = NotificationParser.tokens(p.normalized)
        for (r in db.recent(days = 60)) {
            val bothRef = p.reference != null && r.reference != null
            if (bothRef && p.reference.equals(r.reference, ignoreCase = true)) {
                return DupResult(true, r.id, "رقم العملية ${p.reference} مكرر — سُجّل سابقاً، يُحتمل أن الإشعار احتيال", 1.0, byReference = true)
            }
            val sim = jaccard(mine, NotificationParser.tokens(r.text))
            val sameAmount = p.amount != null && p.amount == r.amount
            val sameTime = p.dateTime != null && p.dateTime == r.dateTime
            if (sameAmount && sameTime && sim >= 0.85) {
                val why = if (bothRef) "نص متطابق تقريباً (نفس المبلغ والوقت) لكن برقم مرجع مختلف — قد يكون معاد صياغته أو مزوراً"
                else "نفس المبلغ والوقت ونص مشابه لإشعار سابق"
                return DupResult(true, r.id, why, sim)
            }
            if (!bothRef && sim >= 0.92) {
                return DupResult(true, r.id, "نص مطابق تقريباً لإشعار سابق (${(sim * 100).toInt()}%)", sim)
            }
        }
        return DupResult(false)
    }
}
