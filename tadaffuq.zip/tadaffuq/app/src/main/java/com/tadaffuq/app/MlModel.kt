package com.tadaffuq.app

import android.content.Context
import org.json.JSONObject
import kotlin.math.exp

/** انحدار لوجستي يعمل على الجهاز؛ الأوزان من assets/model.json. */
class MlModel(private val weights: DoubleArray, private val bias: Double) {

    fun predict(s: Signals): Double {
        val x = s.toVector()
        var z = bias
        for (i in x.indices) z += weights[i] * x[i]
        return 1.0 / (1.0 + exp(-z))
    }

    companion object {
        fun load(ctx: Context): MlModel {
            val o = JSONObject(ctx.assets.open("model.json").bufferedReader().use { it.readText() })
            val names = o.getJSONArray("features").let { a -> (0 until a.length()).map { a.getString(it) } }
            require(names == Signals.FEATURE_NAMES) { "ترتيب الخصائص في model.json لا يطابق التطبيق" }
            val w = o.getJSONArray("weights").let { a -> DoubleArray(a.length()) { a.getDouble(it) } }
            return MlModel(w, o.getDouble("bias"))
        }
    }
}
