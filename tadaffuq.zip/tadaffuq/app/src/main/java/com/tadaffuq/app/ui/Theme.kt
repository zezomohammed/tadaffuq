package com.tadaffuq.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tadaffuq.app.Level

val Safe = Color(0xFF1F9D63)
val Warn = Color(0xFFE0A100)
val Danger = Color(0xFFD64545)
val Alert = Color(0xFFE5772B)

val HeroBrush = Brush.linearGradient(listOf(Color(0xFF0B7A75), Color(0xFF16B3A5)))

fun levelColor(l: Level): Color = when (l) {
    Level.SAFE -> Safe
    Level.SUSPICIOUS -> Warn
    Level.FORGED -> Danger
    Level.DUPLICATE -> Danger
    Level.ACCOUNT_MISMATCH -> Alert
}

fun levelShort(l: Level): String = when (l) {
    Level.SAFE -> "مؤكد"
    Level.SUSPICIOUS -> "مشبوه"
    Level.FORGED -> "مزوّر"
    Level.DUPLICATE -> "مكرر"
    Level.ACCOUNT_MISMATCH -> "حساب مختلف"
}

@Composable
fun TadaffuqTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFF4FD1C5),
            onPrimary = Color(0xFF00201E),
            primaryContainer = Color(0xFF123C3A),
            background = Color(0xFF0A1012),
            surface = Color(0xFF131C1F),
            onSurface = Color(0xFFE6EEF0),
            surfaceVariant = Color(0xFF1B2629),
            onSurfaceVariant = Color(0xFFA9BDC1),
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF0B7A75),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFD7F3EF),
            background = Color(0xFFF2F6F7),
            surface = Color.White,
            onSurface = Color(0xFF0F1B1D),
            surfaceVariant = Color(0xFFE6EDEF),
            onSurfaceVariant = Color(0xFF51666A),
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(26.dp),
        ),
        content = content,
    )
}

@Composable
fun StatusChip(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
