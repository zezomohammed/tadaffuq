package com.tadaffuq.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tadaffuq.app.Analysis
import com.tadaffuq.app.AppState
import com.tadaffuq.app.Level
import com.tadaffuq.app.money
import com.tadaffuq.app.shareFile

@Composable
fun ScanScreen(state: AppState, actions: ScanActions) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var showText by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("فحص إشعار", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)

        if (state.result == null && !state.busy) {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
                Column(
                    Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("🧾", fontSize = 44.sp)
                    Text("صوّر الإشعار أو اختر لقطة شاشة", fontWeight = FontWeight.Bold)
                    Text(
                        "يقرأ تدفق رقم العملية والحساب والمبلغ، ويتحقق منها ثم يسجّل السليم في إكسل اليوم.",
                        fontSize = 13.sp, color = cs.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = actions.onCamera, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f)) { Text("📷 تصوير") }
                        OutlinedButton(onClick = actions.onPick, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f)) { Text("🖼️ معرض") }
                    }
                }
            }
        }

        state.error?.let {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Danger.copy(alpha = 0.12f))) {
                Text(it, color = Danger, modifier = Modifier.padding(14.dp), fontSize = 14.sp)
            }
        }

        state.bitmap?.let {
            Image(
                it.asImageBitmap(), contentDescription = "صورة الإشعار",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp).clip(RoundedCornerShape(20.dp)),
            )
        }

        if (state.busy) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(Modifier.height(28.dp))
                Text("جارٍ قراءة الإشعار وفحصه...")
            }
        }

        state.result?.let { a ->
            ResultCard(a)
            FieldsCard(a)

            state.recorded?.let { r ->
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Safe.copy(alpha = 0.12f))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (r.file != null) "تم تسجيل العملية في ${r.file.name}"
                            else "تم تسجيل العملية، لكن تعذّر إنشاء ملف الإكسل.",
                            fontWeight = FontWeight.Bold, color = Safe,
                        )
                        r.file?.let { f ->
                            Button(onClick = { shareFile(ctx, f) }, shape = RoundedCornerShape(14.dp)) { Text("فتح / مشاركة ملف اليوم") }
                        }
                    }
                }
            }

            if (state.recorded == null) {
                OutlinedTextField(
                    value = state.editRef,
                    onValueChange = { state.editRef = it },
                    label = { Text("رقم العملية (عدّله إن أخطأت القراءة)") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(onClick = { state.recheck() }, shape = RoundedCornerShape(14.dp)) { Text("أعد الفحص بهذا الرقم") }
            }

            OutlinedButton(onClick = { showText = !showText }, shape = RoundedCornerShape(14.dp)) {
                Text(if (showText) "إخفاء النص المقروء" else "عرض النص المقروء (للتأكد من دقة القراءة)")
            }
            if (showText) {
                Text(
                    a.rawText, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(cs.surfaceVariant).padding(12.dp),
                )
            }

            Button(onClick = { state.reset() }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Text("فحص إشعار جديد")
            }
        }
    }
}

@Composable
private fun ResultCard(a: Analysis) {
    val c = levelColor(a.level)
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = c.copy(alpha = 0.12f))) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(a.level.label, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = c)
            LinearProgressIndicator(
                progress = { a.score.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                color = c,
                trackColor = c.copy(alpha = 0.18f),
            )
            Text(
                "درجة الخطر ${(a.score * 100).toInt()}%  ·  قواعد ${(a.ruleScore * 100).toInt()}%  ·  نموذج ${(a.mlScore * 100).toInt()}%",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (a.reasons.isEmpty()) {
                Text(
                    "الصيغة والحساب ورقم العملية سليمة. ننصح مع ذلك بمطابقة الرصيد في تطبيق البنك الرسمي.",
                    fontSize = 14.sp,
                )
            } else {
                a.reasons.forEach { Text("• $it", fontSize = 14.sp) }
            }
        }
    }
}

@Composable
private fun FieldsCard(a: Analysis) {
    val cs = MaterialTheme.colorScheme
    val p = a.parsed
    val o = a.official
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
            FieldRow("رقم العملية", p.reference)
            FieldRow("التاريخ والزمن", p.dateTime)
            FieldRow("المبلغ", p.amount?.let { "${money(it)} ${p.currency ?: "SDG"}" })
            FieldRow("من حساب", o?.fromAccount)
            FieldRow("الى حساب", o?.toAccount ?: p.accounts.firstOrNull())
            FieldRow("اسم المرسل اليه", o?.recipientName)
        }
    }
}

@Composable
private fun FieldRow(label: String, value: String?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value ?: "—", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}
