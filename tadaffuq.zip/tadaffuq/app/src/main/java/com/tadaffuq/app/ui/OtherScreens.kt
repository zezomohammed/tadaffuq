package com.tadaffuq.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tadaffuq.app.AppState
import com.tadaffuq.app.money

@Composable
fun ReportsScreen(state: AppState) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("التقارير", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text(
            "لكل يوم ملف إكسل بالتاريخ والزمن ورقم العملية والمبلغ، يضم الإشعارات المؤكدة فقط.",
            fontSize = 13.sp, color = cs.onSurfaceVariant,
        )
        state.reportError?.let { Text(it, color = Danger, fontSize = 13.sp) }

        if (state.days.isEmpty()) {
            EmptyState("📊", "لا توجد تقارير بعد", "ستظهر الأيام هنا بعد تسجيل أول إشعار مؤكد.")
        } else {
            state.days.forEach { d ->
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surface),
                    modifier = Modifier.fillMaxWidth().clickable { state.exportAndShare(ctx, d.day) },
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(d.day, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("${d.count} عملية مؤكدة", fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${money(d.total)} ج.س", fontWeight = FontWeight.Bold)
                            Text("اضغط للتصدير والمشاركة", fontSize = 11.sp, color = cs.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(state: AppState) {
    val cs = MaterialTheme.colorScheme
    var input by remember { mutableStateOf(state.account) }
    var err by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("الإعدادات", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)

        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("حسابك المستلِم", fontWeight = FontWeight.Bold)
                Text(
                    "يقارنه تدفق بحقل «الى حساب» في كل إشعار؛ أي اختلاف يظهر كتنبيه.",
                    fontSize = 13.sp, color = cs.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it; err = null; saved = false },
                    label = { Text("مثل 0273 0854 1345 0001") },
                    singleLine = true,
                    isError = err != null,
                    supportingText = err?.let { { Text(it) } },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = {
                        err = state.saveAccount(input)
                        if (err == null) { input = state.account; saved = true }
                    },
                    shape = RoundedCornerShape(14.dp),
                ) { Text("حفظ الحساب") }
                if (saved) Text("تم الحفظ ✓", color = Safe, fontSize = 13.sp)
            }
        }

        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("عن تدفق", fontWeight = FontWeight.Bold)
                Text(
                    "يكشف تدفق مؤشرات التزوير وتكرار رقم العملية والخلل في رقم الحساب، لكنه لا يتصل بالبنك. " +
                        "«لا مؤشرات» لا تعني أن الإشعار صحيح؛ تأكد دائماً من تطبيق البنك الرسمي.",
                    fontSize = 13.sp, color = cs.onSurfaceVariant,
                )
            }
        }

        OutlinedButton(
            onClick = { confirmClear = true },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger),
        ) { Text("مسح كل السجلات") }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("مسح كل السجلات؟") },
            text = { Text("سيُمسح سجل الفحوص وأرقام العمليات المسجّلة، فلن يُكشف تكرار الإشعارات السابقة. ملفات الإكسل المصدّرة تبقى.") },
            confirmButton = {
                TextButton(onClick = { state.clearAll(); confirmClear = false }) { Text("مسح", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("إلغاء") } },
        )
    }
}
