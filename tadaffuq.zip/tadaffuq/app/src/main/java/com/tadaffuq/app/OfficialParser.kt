package com.tadaffuq.app

import java.time.LocalDateTime

/** مواصفات إشعار بنك الخرطوم الرسمي (من النموذج المرفق). عدّلها إذا اختلفت الصيغة. */
object BankFormat {
    /** عدد خانات رقم العملية — ١١ رقماً في النموذج؛ غيّره إن كانت أرقام البنك بطول آخر. */
    const val OP_DIGITS = 11
    val OP = Regex("^\\d{$OP_DIGITS}$")
    val ACCOUNT = Regex("^\\d{4} \\d{4} \\d{4} \\d{4}$")
    val AMOUNT = Regex("^\\d{1,3}(,\\d{3})*\\.\\d{2}$")
    val DATETIME = Regex("^(\\d{1,2})-([A-Za-z0-9]{3})-(\\d{4}) (\\d{2}):(\\d{2}):(\\d{2})$")

    /** يحوّل ١٦ رقماً إلى التنسيق الرسمي «xxxx xxxx xxxx xxxx»، أو null إن لم يكن ١٦ رقماً. */
    fun formatAccount(input: String): String? {
        val d = NotificationParser.normalize(input).filter { it.isDigit() }
        return if (d.length == 16) d.chunked(4).joinToString(" ") else null
    }
}

data class OfficialFields(
    val operationNumber: String?,
    val dateTime: LocalDateTime?,
    val fromAccount: String?,
    val toAccount: String?,
    val recipientName: String?,
    val amount: Double?,
    val problems: List<String>,
) {
    val isComplete: Boolean
        get() = problems.isEmpty() && operationNumber != null && dateTime != null &&
            toAccount != null && amount != null
}

object OfficialParser {
    private val L_OP = Regex("رقم العمليه")
    private val L_DT = Regex("التاريخ\\s*و?\\s*الزمن")
    private val L_FROM = Regex("من حساب")
    private val L_TO = Regex("الي حساب")
    private val L_NAME = Regex("اسم المرسل اليه")
    private val L_AMOUNT = Regex("المبلغ")

    private val MONTHS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

    /** يرجع null إذا لم يظهر في النص أكثر من عنوانين من عناوين الإشعار (ليس بصيغة بنكك). */
    fun parse(raw: String, now: LocalDateTime = LocalDateTime.now()): OfficialFields? {
        val lines = raw.lines().map { NotificationParser.normalize(it) }.filter { it.isNotEmpty() }

        var labelsFound = 0
        fun value(label: Regex): String? {
            for ((i, line) in lines.withIndex()) {
                val m = label.find(line) ?: continue
                labelsFound++
                val rest = line.removeRange(m.range).trim().trim(':', '-').trim()
                return if (rest.isNotEmpty()) rest else lines.getOrNull(i + 1)
            }
            return null
        }

        val op = value(L_OP)
        val dtRaw = value(L_DT)
        val from = value(L_FROM)
        val to = value(L_TO)
        val name = value(L_NAME)
        val amountRaw = value(L_AMOUNT)
        if (labelsFound < 3) return null

        val problems = mutableListOf<String>()

        if (op == null) problems += "حقل رقم العملية غير موجود"
        else if (!BankFormat.OP.matches(op)) problems += "رقم العملية «$op» لا يطابق الصيغة الرسمية (${BankFormat.OP_DIGITS} رقماً بلا فراغات)"

        var dt: LocalDateTime? = null
        if (dtRaw == null) problems += "حقل التاريخ والزمن غير موجود"
        else {
            val m = BankFormat.DATETIME.matchEntire(dtRaw)
            if (m == null) problems += "التاريخ والزمن «$dtRaw» لا يطابق الصيغة الرسمية (28-Oct-2026 16:21:06)"
            else {
                val mon = MONTHS.indexOf(m.groupValues[2].lowercase().replace('0', 'o')) + 1
                dt = try {
                    if (mon == 0) null else LocalDateTime.of(
                        m.groupValues[3].toInt(), mon, m.groupValues[1].toInt(),
                        m.groupValues[4].toInt(), m.groupValues[5].toInt(), m.groupValues[6].toInt()
                    )
                } catch (e: Exception) { null }
                if (dt == null) problems += "تاريخ غير صالح «$dtRaw»"
                else if (dt.isAfter(now.plusMinutes(10))) problems += "تاريخ العملية في المستقبل"
            }
        }

        if (from == null) problems += "حقل «من حساب» غير موجود"
        else if (!BankFormat.ACCOUNT.matches(from)) problems += "«من حساب» ($from) بتنسيق مخالف للرسمي (xxxx xxxx xxxx xxxx)"

        if (to == null) problems += "حقل «الى حساب» غير موجود"
        else if (!BankFormat.ACCOUNT.matches(to)) problems += "«الى حساب» ($to) بتنسيق أو مسافات مخالفة للرسمي (xxxx xxxx xxxx xxxx)"

        var amount: Double? = null
        if (amountRaw == null) problems += "حقل المبلغ غير موجود"
        else if (!BankFormat.AMOUNT.matches(amountRaw)) problems += "المبلغ «$amountRaw» بتنسيق مخالف (مثل 10,000.00)"
        else amount = amountRaw.replace(",", "").toDoubleOrNull()

        return OfficialFields(op, dt, from, to, name, amount, problems)
    }
}
