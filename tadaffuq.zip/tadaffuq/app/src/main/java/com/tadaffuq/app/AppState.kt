package com.tadaffuq.app

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** حالة التطبيق المشتركة بين الشاشات. */
class AppState(ctx: Context) {
    val analyzer = Analyzer(ctx)
    private val ocr = OcrEngine(ctx)

    /** 0 الرئيسية · 1 فحص · 2 التقارير · 3 الإعدادات */
    var tab by mutableIntStateOf(0)

    var bitmap by mutableStateOf<Bitmap?>(null)
    var busy by mutableStateOf(false)
    var result by mutableStateOf<Analysis?>(null)
    var recorded by mutableStateOf<Recorded?>(null)
    var error by mutableStateOf<String?>(null)
    var editRef by mutableStateOf("")

    var account by mutableStateOf(analyzer.accountStore.account)
    var stats by mutableStateOf(DayStats())
    var recent by mutableStateOf<List<ScanEntry>>(emptyList())
    var days by mutableStateOf<List<DaySummary>>(emptyList())
    var reportError by mutableStateOf<String?>(null)

    fun today(): String = LocalDate.now().toString()

    fun refresh() {
        stats = analyzer.stats(today())
        recent = analyzer.recentScans(20)
        days = analyzer.daySummaries()
    }

    suspend fun scan(bmp: Bitmap) {
        busy = true; error = null; result = null; recorded = null; bitmap = bmp
        try {
            val (a, rec) = withContext(Dispatchers.Default) {
                val text = ocr.read(bmp)
                if (NotificationParser.normalize(text).length < 10) {
                    throw IllegalStateException("لم أتمكن من قراءة نص واضح من الصورة، جرّب صورة أوضح.")
                }
                val a = analyzer.analyze(text)
                Pair(a, analyzer.process(a))
            }
            result = a
            recorded = rec
            editRef = a.parsed.reference ?: ""
            refresh()
        } catch (e: Exception) {
            error = e.message ?: "حدث خطأ غير متوقع"
        } finally {
            busy = false
        }
    }

    fun recheck() {
        val a = result ?: return
        val a2 = analyzer.analyze(a.rawText, editRef)
        recorded = analyzer.process(a2)
        result = a2
        refresh()
    }

    fun reset() {
        result = null; bitmap = null; recorded = null; error = null; editRef = ""
    }

    /** يرجع رسالة خطأ أو null عند النجاح. */
    fun saveAccount(input: String): String? {
        val f = BankFormat.formatAccount(input) ?: return "يجب أن يتكون الحساب من 16 رقماً"
        analyzer.accountStore.account = f
        account = f
        return null
    }

    fun exportAndShare(ctx: Context, day: String) {
        val f = analyzer.exportDay(day)
        if (f == null) reportError = "تعذّر إنشاء ملف الإكسل"
        else { reportError = null; shareFile(ctx, f) }
    }

    fun clearAll() {
        analyzer.clearHistory()
        reset()
        refresh()
    }
}
