package com.tadaffuq.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.FileProvider
import com.tadaffuq.app.ui.HomeScreen
import com.tadaffuq.app.ui.ReportsScreen
import com.tadaffuq.app.ui.ScanActions
import com.tadaffuq.app.ui.ScanScreen
import com.tadaffuq.app.ui.SettingsScreen
import com.tadaffuq.app.ui.TadaffuqTheme
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TadaffuqTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Root()
                }
            }
        }
    }
}

private val TABS = listOf("الرئيسية" to "🏠", "فحص" to "📷", "التقارير" to "📊", "الإعدادات" to "⚙️")

@Composable
fun Root() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val state = remember { AppState(ctx) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(Unit) { state.refresh() }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { u ->
            loadBitmap(ctx, u)?.let { b -> state.tab = 1; scope.launch { state.scan(b) } }
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { u ->
            loadBitmap(ctx, u)?.let { b -> state.tab = 1; scope.launch { state.scan(b) } }
        }
    }

    // لا يُسمح بالتصوير قبل حفظ حساب العميل
    fun guarded(action: () -> Unit): () -> Unit = {
        if (state.account.isBlank()) state.tab = 3 else action()
    }

    val actions = ScanActions(
        onPick = guarded { pick.launch("image/*") },
        onCamera = guarded {
            val dir = File(ctx.cacheDir, "images").apply { mkdirs() }
            val f = File.createTempFile("shot", ".jpg", dir)
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
            cameraUri = uri
            camera.launch(uri)
        },
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                TABS.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = state.tab == i,
                        onClick = { state.tab = i; if (i == 0 || i == 2) state.refresh() },
                        icon = { Text(icon) },
                        label = { Text(label) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (state.tab) {
                0 -> HomeScreen(state, actions)
                1 -> ScanScreen(state, actions)
                2 -> ReportsScreen(state)
                else -> SettingsScreen(state)
            }
        }
    }
}
