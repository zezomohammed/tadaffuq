package com.tadaffuq.app

data class ParsedNotice(
    val normalized: String,
    val amount: Double?,
    val currency: String?,
    val reference: String?,
    val dateTime: String?, // "yyyy-MM-dd" أو "yyyy-MM-dd HH:mm"
    val links: List<String>,
    val phones: List<String>,
    val accounts: List<String> = emptyList(), // أرقام الحسابات الواردة في الإشعار (قد تكون مقنّعة مثل ****1234)
)

object NotificationParser {
    private const val ARABIC_INDIC = "٠١٢٣٤٥٦٧٨٩"
    private const val EASTERN_INDIC = "۰۱۲۳۴۵۶۷۸۹"

    /** توحيد الأرقام والحروف حتى تتطابق الكلمات المفتاحية رغم أخطاء OCR والتشكيل. */
    fun normalize(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (c in raw) {
            val a = ARABIC_INDIC.indexOf(c)
            val e = EASTERN_INDIC.indexOf(c)
            sb.append(
                when {
                    a >= 0 -> '0' + a
                    e >= 0 -> '0' + e
                    c == '٫' -> '.'
                    c == '٬' || c == '،' -> ','
                    else -> c
                }
            )
        }
        return sb.toString()
            .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ة', 'ه').replace('ى', 'ي')
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private const val CUR = "(?:SDG|SAR|USD|EGP|AED|QAR|KWD|جنيه|ج\\.س|ريال|دولار|درهم|دينار|\\$)"
    private const val NUM = "(\\d{1,3}(?:,\\d{3})+(?:\\.\\d+)?|\\d+(?:\\.\\d+)?)"
    private val amountAfter = Regex("$NUM\\s*($CUR)", RegexOption.IGNORE_CASE)
    private val amountBefore = Regex("($CUR)\\s*$NUM", RegexOption.IGNORE_CASE)
    private val amountLabel = Regex("(?:مبلغ|amount)\\s*:?\\s*$NUM", RegexOption.IGNORE_CASE)

    private val refRe = Regex(
        "(?:ref(?:erence)?(?: no)?\\.?|رقم العمليه|رقم المرجع|رقم المعامله|المرجع|مرجع|transaction id|txn)\\s*[:#\\-]?\\s*([A-Za-z0-9]{6,})",
        RegexOption.IGNORE_CASE
    )
    private val dateYmd = Regex("(?<!\\d)(\\d{4})[-/.](\\d{1,2})[-/.](\\d{1,2})(?!\\d)")
    private val dateDmy = Regex("(?<!\\d)(\\d{1,2})[-/.](\\d{1,2})[-/.](\\d{4})(?!\\d)")
    private val timeRe = Regex("(?<!\\d)(\\d{1,2}):(\\d{2})(?!\\d)")
    private val linkRe = Regex(
        "(?i)\\b(?:https?://|www\\.)\\S+|\\b[a-z0-9-]+\\.(?:com|net|org|info|xyz|top|online|site|link|cc|tk|ml|ly|gl)/\\S*"
    )
    private val phoneRe = Regex("(?<![\\d])\\+?\\d{9,14}(?![\\d])")
    private val accountRe = Regex(
        "(?:رقم الحساب|الي حساب|الى حساب|حساب|account(?: no| number)?|acct|a/c|iban)\\s*[:#\\-]?\\s*([A-Za-z0-9*•]{4,}(?:[-\\s][0-9*•]{2,})*)",
        RegexOption.IGNORE_CASE
    )

    fun parse(raw: String): ParsedNotice {
        val t = normalize(raw)

        var amount: Double? = null
        var currency: String? = null
        amountAfter.find(t)?.let {
            amount = it.groupValues[1].replace(",", "").toDoubleOrNull(); currency = it.groupValues[2]
        } ?: amountBefore.find(t)?.let {
            amount = it.groupValues[2].replace(",", "").toDoubleOrNull(); currency = it.groupValues[1]
        } ?: amountLabel.find(t)?.let {
            amount = it.groupValues[1].replace(",", "").toDoubleOrNull()
        }

        val ref = refRe.find(t)?.groupValues?.get(1)

        var date: String? = null
        dateYmd.find(t)?.let { m ->
            date = "%04d-%02d-%02d".format(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
        } ?: dateDmy.find(t)?.let { m ->
            date = "%04d-%02d-%02d".format(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
        }
        if (date != null) {
            timeRe.find(t)?.let { m ->
                date += " %02d:%02d".format(m.groupValues[1].toInt(), m.groupValues[2].toInt())
            }
        }

        val links = linkRe.findAll(t).map { it.value.trimEnd('.', ',', ')') }.toList()
        val phones = phoneRe.findAll(t).map { it.value }.filter { it != ref }.toList()

        val accounts = accountRe.findAll(t).map { it.groupValues[1].trim() }
            .filter { it.any { c -> c.isDigit() } && !it.equals(ref, ignoreCase = true) }.toList()

        return ParsedNotice(t, amount, currency, ref, date, links, phones.filter { p -> accounts.none { it.filter(Char::isDigit) == p.trimStart('+') } }, accounts)
    }

    fun tokens(normalized: String): Set<String> =
        normalized.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }.toSet()
}
